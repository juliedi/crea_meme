<?php

class Film {

	public function getActeur($id) {
		global $db;
		$results = $db->query("SELECT * FROM acteurs JOIN a_joue ON acteurs.id=a_joue.id_Acteurs WHERE a_joue.id=$id");        
        return $results->fetchAll();
    }
    
    public function getGenre($id) {
        global $db;
        $resultgenre = $db->query("SELECT * FROM genre JOIN a ON genre.id=a.id_Genre WHERE a.id=$id");
        return $resultgenre->fetchAll();
    }

    public function getFilm($id) {        
        global $db;
        $resultfilm = $db->query("SELECT * FROM titre WHERE titre.id=$id");
        return $resultfilm->fetch();
    }

    public function getRealisateur($id) {        
        global $db;        
        $resultrea = $db->query("SELECT * FROM realisateurs WHERE realisateurs.id=$id");
        return $resultrea->fetch();
    }   
}
?>