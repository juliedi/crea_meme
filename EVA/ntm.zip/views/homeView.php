<!DOCTYPE html>
<html>
	<head>
		<title>Home</title>
	</head>
	<body>
		<h1>Home</h1>

		<a href="<?= $BASE_URL ?>films"><h2>Meilleurs films de tous les temps</h2></a>
	</body>
</html>